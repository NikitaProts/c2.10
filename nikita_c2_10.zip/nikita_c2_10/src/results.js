const progressCats = document.querySelector('.cats');
const progressDogs = document.querySelector('.dogs');
const progressParrots = document.querySelector('.parrots');

const header = new Headers({
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Origin': '*'
})

const url = new URL('https://sf-pyw.mosyag.in/sse/vote/stats')

const ES = new EventSource(url, header)

ES.onerror = error => {
    ES.readyState ? progressCats.textContent = "Some error" : null;
}

ES.onmessage = message => {    
    const d = JSON.parse(message.data);
    const tot = d.cats + d.dogs + d.parrots;    
    progressCats.style.cssText = `width: ${d.cats*100/tot}%;`
    progressCats.textContent = `Cats votes: ${d.cats} (${(d.cats*100/tot).toFixed(2)}%)`;
    progressDogs.style.cssText = `width: ${d.dogs*100/tot}%;`
    progressDogs.textContent = `Dogs votes: ${d.dogs} (${(d.dogs*100/tot).toFixed(2)}%)`;
    progressParrots.style.cssText = `width: ${d.parrots*100/tot}%;`
    progressParrots.textContent = `Parrots votes: ${d.parrots} (${(d.parrots*100/tot).toFixed(2)}%)`;
}