// Отправляет форму без перехода на action URL
$('form').submit(function(){
    $.post($(this).attr('action'), $(this).serialize(), function(response){},'json');
    return false;
});

// Прячет кнопки
$('.btn').click(function(){	
	$('.buttons').removeClass('d-flex');
	$('.buttons').addClass('d-none');
	$('.results').removeClass('d-none');
	$('.results').addClass('d-flex');
});